import { memo, useCallback, useMemo } from 'react';
import { TextField as MuiTextField } from '@mui/material';
import { useCleanParentProps } from './helper/clean-parent-props';
import { pickColLayoutProps } from './helper/clean-grid-props';
import { useFormField, UseFormFieldProps } from './form-provider';
import { Info } from './info';
import { ColPadded } from '../grid';
import type { FormControlProps, TextEntryProps } from './control-props';

export type TextFieldProps = UseFormFieldProps & FormControlProps & TextEntryProps & {
  autoFocus?: boolean;
  pattern?: string;
  spellCheck?: boolean;
  inputMode?: string;
  autoComplete?: string;
};

export const TextField = memo((props: TextFieldProps) => {
  const { field, readOnly, errorMui, valueProp, identityProps } = useFormField(props);

  const onBlur = useCallback((e: React.FocusEvent<HTMLInputElement>) => {
    field.onBlur(e.target.value);
    props.onBlur?.(e as any);
  }, [field, props.onBlur]);

  const onChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    field.onChange(e.target.value);
    props.onChange?.(e as any);
  }, [field, props.onChange]);

  const parentProps = useCleanParentProps(props, 'textField');
  const placeholder = parentProps.placeholder ?? props.placeholder;

  const htmlInputProps = useMemo(() => ({
    readOnly,
    maxLength: props.maxLength,
    minLength: props.minLength,
    pattern: props.pattern,
    spellCheck: props.spellCheck,
    inputMode: props.inputMode,
    autoComplete: props.autoComplete,
    ...(placeholder ? { placeholder } : {}),
  }), [readOnly, props.maxLength, props.minLength, props.pattern, props.spellCheck, props.inputMode, props.autoComplete, placeholder]);

  return (
    <ColPadded {...pickColLayoutProps(props)}>
      <MuiTextField
        fullWidth
        {...identityProps}
        label={props.label}
        placeholder={placeholder}
        inputRef={field.ref}
        onBlur={onBlur}
        onChange={onChange}
        autoFocus={props.autoFocus}
        {...parentProps}
        {...valueProp}
        {...errorMui}
        slotProps={{
          ...parentProps.slotProps,
          htmlInput: {
            ...parentProps.slotProps?.htmlInput,
            ...htmlInputProps,
          },
        }}
      />
      {props.info && <Info id={`${field.name}Info`} info={props.info} />}
    </ColPadded>
  );
});

TextField.displayName = 'TextField';
