import { memo, useCallback, useEffect } from 'react';
import {
  TextareaAutosize,
  InputLabel,
  FormHelperText,
} from '@mui/material';
import { color } from '../../theme-material';
import { useCleanParentProps } from './helper/clean-parent-props';
import { pickColLayoutProps } from './helper/clean-grid-props';
import { useFormField, UseFormFieldProps } from './form-provider';
import { Info } from './info';
import { ColPadded } from '../grid';
import type { FormControlProps, TextEntryProps } from './control-props';

export type TextareaProps = UseFormFieldProps & FormControlProps & TextEntryProps & {
  charCount?: number;
  minRows?: number;
};

export const Textarea = memo((props: TextareaProps) => {
  const { field, readOnly, errorMui, valueProp, identityProps } = useFormField(props);

  const onBlur = useCallback((e: React.FocusEvent<HTMLTextAreaElement>) => {
    field.onBlur(e.target.value);
    props.onBlur?.(e as any);
  }, [field, props.onBlur]);

  const onChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    field.onChange(e.target.value);
    props.onChange?.(e as any);
  }, [field, props.onChange]);

  const currentLength = ((field.value as string) ?? '').length;
  const isWithinLimit = props.charCount ? currentLength <= props.charCount : true;
  const msgChars = `${currentLength} / ${props.charCount} characters`;
  const hasCountError = !!props.charCount && !isWithinLimit;

  useEffect(() => {
    if (!props.charCount) return;

    const handleSubmit = (event: Event) => {
      if (!isWithinLimit) {
        event.preventDefault();
        event.stopPropagation();
      }
    };

    let form: HTMLFormElement | null = null;
    if (field.ref?.current) {
      form = (field.ref.current as HTMLElement).closest('form');
    }
    if (!form) form = document.querySelector('form');

    if (form) {
      form.addEventListener('submit', handleSubmit, true);
      return () => form!.removeEventListener('submit', handleSubmit, true);
    }
  }, [isWithinLimit, currentLength, props.charCount, field.ref]);

  const hasError = errorMui?.error || hasCountError;
  const labelStyle = hasError ? { color: color.cobe1.red } : {};
  const parentProps = useCleanParentProps(props, 'textarea');
  const placeholder = props.placeholder ?? parentProps.placeholder;

  return (
    <ColPadded {...pickColLayoutProps(props)}>
      <InputLabel
        htmlFor={field.name}
        style={{
          ...labelStyle,
          display: 'block',
          marginBottom: 2,
          marginTop: 0,
          lineHeight: 1.1,
          transform: 'none',
          fontSize: '0.875rem',
        }}
      >
        {props.label}
      </InputLabel>
      <TextareaAutosize
        style={{
          width: '100%',
          border: hasError
            ? `1px solid ${color.cobe1.red}`
            : readOnly
              ? '0px solid transparent'
              : `1px solid ${(color as any).cobe1?.grey ?? '#ccc'}`,
          borderRadius: 4,
          padding: 8,
          outline: 'none',
          resize: readOnly ? 'none' : 'vertical',
          fontFamily: 'inherit',
          fontSize: 14,
          lineHeight: 1.5,
          color: 'inherit',
        }}
        {...identityProps}
        {...(props.minRows && { minRows: props.minRows })}
        ref={field.ref}
        onBlur={onBlur}
        onChange={onChange}
        {...parentProps}
        {...valueProp}
        placeholder={placeholder}
        readOnly={readOnly}
        disabled={props.disabled}
        maxLength={props.maxLength}
        minLength={props.minLength}
      />
      {props.info && <Info id={`${field.name}Info`} info={props.info} />}
      {props.charCount && (
        <FormHelperText
          className="primaryText"
          style={{ marginTop: -2 }}
        >
          {msgChars}
        </FormHelperText>
      )}
      {errorMui?.helperText && (
        <FormHelperText className="Mui-error" style={{ marginTop: -5 }}>
          {errorMui.helperText}
        </FormHelperText>
      )}
    </ColPadded>
  );
});

Textarea.displayName = 'Textarea';
