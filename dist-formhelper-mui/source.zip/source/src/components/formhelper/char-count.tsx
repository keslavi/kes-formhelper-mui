import { memo, useCallback, useMemo, useEffect, ReactNode } from 'react';
import { TextField as MuiTextField } from '@mui/material';
import { color } from '../../theme-material';
import { useCleanParentProps } from './helper/clean-parent-props';
import { pickColLayoutProps } from './helper/clean-grid-props';
import { useFormField, UseFormFieldProps } from './form-provider';
import { Info } from './info';
import { ColPadded } from '../grid';
import type { FormControlProps, TextEntryProps } from './control-props';

const CharMessage = ({
  msg,
  children,
}: {
  msg: string;
  children?: ReactNode;
}) => (
  <>
    <span style={{ color: color.primary.gray }}>
      {msg}
    </span>
    {children && (
      <>
        <br />
        {children}
      </>
    )}
  </>
);

export type CharCountProps = UseFormFieldProps & FormControlProps & TextEntryProps & {
  charCount: number;
  autoFocus?: boolean;
  pattern?: string;
  spellCheck?: boolean;
  inputMode?: string;
  autoComplete?: string;
};

export const CharCount = memo((props: CharCountProps) => {
  const { field, readOnly, errorMui, valueProp, identityProps } = useFormField(props);

  const onBlur = useCallback((e: React.FocusEvent<HTMLInputElement>) => {
    field.onBlur(e.target.value);
    props.onBlur?.(e as any);
  }, [field, props.onBlur]);

  const onChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    field.onChange(e.target.value);
    props.onChange?.(e as any);
  }, [field, props.onChange]);

  const inputProps = useMemo(() => ({
    readOnly,
    maxLength: props.maxLength,
    minLength: props.minLength,
    pattern: props.pattern,
    spellCheck: props.spellCheck,
    inputMode: props.inputMode,
    autoComplete: props.autoComplete,
  }), [readOnly, props.maxLength, props.minLength, props.pattern, props.spellCheck, props.inputMode, props.autoComplete]);

  const currentLength = (field.value as string)?.length ?? 0;
  const isWithinLimit = currentLength <= props.charCount;
  const msgChars = `${currentLength} / ${props.charCount} characters`;

  // Block form submission when over limit
  useEffect(() => {
    const handleFormSubmit = (event: Event) => {
      if (!isWithinLimit) {
        event.preventDefault();
        event.stopPropagation();
        return false;
      }
    };

    let formElement: HTMLFormElement | null = null;
    if (field.ref?.current) {
      formElement = (field.ref.current as HTMLElement).closest('form');
    }
    if (!formElement) {
      formElement = document.querySelector('form');
    }

    if (formElement) {
      formElement.addEventListener('submit', handleFormSubmit, true);
      return () => {
        formElement!.removeEventListener('submit', handleFormSubmit, true);
      };
    }
  }, [isWithinLimit, currentLength, props.charCount, field.ref]);

  const parentProps = useCleanParentProps(props, 'textField');

  return (
    <ColPadded {...pickColLayoutProps(props)}>
      <MuiTextField
        fullWidth
        {...identityProps}
        label={props.label}
        {...(props.placeholder && { placeholder: props.placeholder })}
        inputRef={field.ref}
        onBlur={onBlur}
        onChange={onChange}
        autoFocus={props.autoFocus}
        {...parentProps}
        {...valueProp}
        slotProps={{ htmlInput: inputProps }}
        {...(errorMui?.error || !isWithinLimit ? { error: true } : {})}
        helperText={
          <CharMessage msg={msgChars}>
            {errorMui.helperText}
          </CharMessage>
        }
      />
      {props.info && <Info id={`${field.name}Info`} info={props.info} />}
    </ColPadded>
  );
});

CharCount.displayName = 'CharCount';
