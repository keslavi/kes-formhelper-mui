import { memo, useCallback, useMemo } from 'react';
import { TextField as MuiTextField } from '@mui/material';
import dayjs from 'dayjs';
import { isEmpty } from 'lodash';
import { useCleanParentProps } from './helper/clean-parent-props';
import { pickColLayoutProps } from './helper/clean-grid-props';
import { useFormField, UseFormFieldProps } from './form-provider';
import { Info } from './info';
import { ColPadded } from '../grid';
import type { FormControlProps, TextEntryProps } from './control-props';

export type DatepickerProps = UseFormFieldProps & FormControlProps & TextEntryProps & {
  min?: string;
  max?: string;
};

const normalizeDateInput = (raw?: any): string | undefined => {
  if (!raw) return raw;

  if (typeof raw === 'string') {
    const isoMatch = raw.match(/^\d{4}-\d{2}-\d{2}/);
    if (isoMatch) return isoMatch[0];
  }

  const parsed = dayjs(raw);
  if (parsed.isValid()) {
    return parsed.format('YYYY-MM-DD');
  }

  return typeof raw === 'string' ? raw : undefined;
};

export const Datepicker = memo((props: DatepickerProps) => {
  const { field, readOnly, errorMui, valueProp, identityProps } = useFormField(props);
  const isReadOnly = readOnly;

  const attributes = useMemo(() => {
    const inputProps: Record<string, string> = {};
    if (!isEmpty(props.min)) inputProps.min = dayjs(props.min).format('YYYY-MM-DD');
    if (!isEmpty(props.max)) inputProps.max = dayjs(props.max).format('YYYY-MM-DD');
    return inputProps;
  }, [props.min, props.max]);

  const normalizedValueProp = useMemo(() => {
    if ('value' in valueProp && valueProp.value !== undefined) {
      return { value: normalizeDateInput(valueProp.value) };
    }
    if ('defaultValue' in valueProp && valueProp.defaultValue !== undefined) {
      return { defaultValue: normalizeDateInput(valueProp.defaultValue) };
    }
    return valueProp;
  }, [valueProp]);

  const displayValue = useMemo(
    () => normalizeDateInput(field?.value ?? (valueProp as any)?.value ?? (valueProp as any)?.defaultValue) ?? '',
    [field?.value, valueProp]
  );

  const onChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    field.onChange(e.target.value);
    props.onChange?.(e as any);
  }, [field, props.onChange]);

  const textFieldParentProps = useCleanParentProps(props, 'textField');
  const readOnlyFieldProps = useMemo(() => {
    const { type, ...rest } = textFieldParentProps as Record<string, unknown>;
    return rest;
  }, [textFieldParentProps]);

  if (isReadOnly) {
    return (
      <ColPadded {...pickColLayoutProps(props)}>
        <MuiTextField
          fullWidth
          type="text"
          {...identityProps}
          label={props.label}
          inputRef={field.ref}
          onBlur={field.onBlur}
          value={
            displayValue
              ? (dayjs(displayValue).isValid()
                ? dayjs(displayValue).format('MM/DD/YYYY')
                : String(displayValue))
              : ''
          }
          {...readOnlyFieldProps}
          {...errorMui}
          slotProps={{
            htmlInput: {
              readOnly: true,
              style: { cursor: 'text' },
            },
          }}
        />
        {props.info && <Info id={`${field.name}Info`} info={props.info} />}
      </ColPadded>
    );
  }

  return (
    <ColPadded {...pickColLayoutProps(props)}>
      <MuiTextField
        fullWidth
        type="date"
        {...identityProps}
        label={props.label}
        inputRef={field.ref}
        onBlur={field.onBlur}
        onChange={onChange}
        {...textFieldParentProps}
        {...normalizedValueProp}
        {...errorMui}
        slotProps={{
          htmlInput: {
            ...attributes,
            style: { cursor: 'pointer' },
          },
        }}
      />
      {props.info && <Info id={`${field.name}Info`} info={props.info} />}
    </ColPadded>
  );
});

Datepicker.displayName = 'Datepicker';
