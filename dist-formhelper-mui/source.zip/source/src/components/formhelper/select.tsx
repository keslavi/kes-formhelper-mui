import React, { useCallback, useMemo } from 'react';
import {
  Select as MuiSelect,
  MenuItem,
  FormControl,
  InputLabel,
  TextField as MuiTextField,
} from '@mui/material';
import { useCleanParentProps } from './helper/clean-parent-props';
import { pickColLayoutProps } from './helper/clean-grid-props';
import { getOptionLabelByKey } from './helper/option-display';
import { useFormField, UseFormFieldProps } from './form-provider';
import { Info } from './info';
import { ColPadded } from '../grid';
import type { FormControlProps } from './control-props';
import type { Option, Options } from './option';

export type SelectOption = Option;

export type SelectProps = UseFormFieldProps & FormControlProps & {
  placeholder?: string;
  options?: Options;
};

export const Select = React.memo((props: SelectProps) => {
  const { field, readOnly, errorMui, valueProp, identityProps } = useFormField(props);
  const isReadOnly = readOnly;

  const renderedOptions = useMemo(() =>
    props.options?.map(x => (
      <MenuItem key={x.key} value={x.key} disabled={!!x.disabled}>{x.text}</MenuItem>
    )) ?? [],
    [props.options]
  );

  const onBlur = useCallback((e: React.FocusEvent) => {
    field.onBlur((e.target as any).value);
    props.onBlur?.(e as any);
  }, [field, props.onBlur]);

  const onChange = useCallback((e: React.ChangeEvent<{ value: unknown }>) => {
    if (props.disabled || readOnly) return;
    field.onChange((e.target as any).value);
    props.onChange?.(e as any);
  }, [field, props.disabled, props.onChange, readOnly]);

  const hasError = !!errorMui.error;

  const rawValue = (field?.value ?? (valueProp as any)?.value ?? (valueProp as any)?.defaultValue) as unknown;
  const displayValue = useMemo(() => getOptionLabelByKey(props.options, rawValue), [props.options, rawValue]);
  const textFieldParentProps = useCleanParentProps(props, 'textField');
  const selectParentProps = useCleanParentProps(props, 'select');

  if (isReadOnly) {
    return (
      <ColPadded {...pickColLayoutProps(props)}>
        <MuiTextField
          fullWidth
          {...identityProps}
          label={props.label}
          inputRef={field.ref}
          onBlur={onBlur}
          value={displayValue}
          placeholder={props.placeholder}
          {...(hasError ? { error: true, helperText: errorMui.helperText } : {})}
          {...textFieldParentProps}
          slotProps={{ htmlInput: { readOnly: true } }}
        />
        {props.info && <Info id={`${field.name}Info`} info={props.info} />}
      </ColPadded>
    );
  }

  return (
    <ColPadded {...pickColLayoutProps(props)}>
      <FormControl fullWidth size={props.sizeInput} error={hasError} disabled={!!props.disabled}>
        <InputLabel id={`${field.name}-label`}>{props.label}</InputLabel>
        <MuiSelect
          labelId={`${field.name}-label`}
          {...identityProps}
          label={props.label ?? ''}
          onBlur={onBlur}
          onChange={onChange as any}
          {...valueProp}
          displayEmpty
          renderValue={(selected: any) => {
            if (!selected || selected === '') {
              return <span style={{ color: '#666' }}>{props.placeholder ?? 'Please Select'}</span>;
            }
            const opt = props.options?.find(o => String(o.key) === String(selected));
            return opt ? opt.text : selected;
          }}
          {...selectParentProps}
        >
          {renderedOptions}
        </MuiSelect>
        {errorMui.error && (
          <div style={{ color: 'red', fontSize: '0.75rem', marginTop: 3 }}>
            {errorMui.helperText}
          </div>
        )}
      </FormControl>
      {props.info && <Info id={`${field.name}Info`} info={props.info} />}
    </ColPadded>
  );
});

Select.displayName = 'Select';
